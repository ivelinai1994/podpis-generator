document.getElementById('generateSignatures').addEventListener('click', generateSignatures);

function generateSignatures() {
    const input = document.getElementById('names').value.trim();
    const nameArray = input.split(' ');

    if (nameArray.length > 5) {
        alert('Можете да въведете максимум 5 имена.');
        return;
    }

    const signaturesContainer = document.getElementById('signatures');
    signaturesContainer.innerHTML = '';

    for (let i = 0; i < 5; i++) {
        const signature = document.createElement('div');
        signature.classList.add('signature');
        signature.innerHTML = `<span>${generateSignature(nameArray, i)}</span>`;
        signaturesContainer.appendChild(signature);
    }
}

function generateSignature(names, style) {
    let signature = names.join(' ');

    switch (style) {
        case 0: return `<i style="font-family: 'Cursive';">${signature}</i>`;
        case 1: return `<strong style="font-family: 'Georgia', serif;">${signature}</strong>`;
        case 2: return `<span style="font-family: 'Comic Sans MS', cursive;">${signature}</span>`;
        case 3: return `<u style="font-family: 'Arial', sans-serif;">${signature}</u>`;
        case 4: return `<span style="font-family: 'Brush Script MT', cursive; color: #28a745;">${signature}</span>`;
        default: return signature;
    }
}
